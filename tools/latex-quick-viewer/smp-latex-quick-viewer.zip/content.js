/**
 * ==============================================================================
 * SMP LaTeX Quick Viewer & Composer — Content Script (Shadow DOM Sandbox UI)
 * ==============================================================================
 * Tích hợp hệ thống LaTeX từ SMP LaTeX Editor:
 * - 8 nhóm ký hiệu & snippet đầy đủ từ SMP LaTeX Editor (render ký hiệu trực quan)
 * - Gợi ý tự động (Autocomplete Hint) khi gõ dấu \ với phím mũi tên & Enter
 * - Hai chế độ Sáng / Tối (Light Mode & Dark Mode) chuyển đổi 1-click
 * - Soạn thảo song song realtime (Live Preview) kèm đếm ký tự, từ, dòng
 * - Xuất và chép ảnh công thức PNG độ nét cao vào Clipboard (Ctrl + V dán vào FB)
 * - Chèn trực tiếp công thức vào ô bình luận Facebook / diễn đàn
 * ==============================================================================
 */

(function () {
    'use strict';

    let modalHost = null;
    let shadowRoot = null;
    let isDragging = false;
    let dragStartX = 0;
    let dragStartY = 0;
    let modalInitialLeft = 0;
    let modalInitialTop = 0;
    let lastActiveEditable = null;
    let currentActiveTab = 'compose'; // 'compose' | 'translate' | 'raw'
    let activeHintIndex = 0;
    let filteredHints = [];
    let currentEditorTarget = null; // Textarea đang nhận autocomplete
    let currentTranslateRawText = ''; // Lưu vết văn bản gốc để tái biên dịch tức thì khi đổi model
    let currentModelPreference = 'max'; // 'max' (mặc định) | 'min'

    // Danh sách gợi ý lệnh quen thuộc chuẩn SMP LaTeX Editor
    const LATEX_SNIPPETS = [
        { text: "\\frac{}{}", displayText: "\\frac{}{} — Phân số", offset: 3 },
        { text: "\\sqrt{}", displayText: "\\sqrt{} — Căn bậc hai", offset: 1 },
        { text: "\\sqrt[]{}", displayText: "\\sqrt[]{} — Căn bậc n", offset: 3 },
        { text: "^{}", displayText: "^{} — Số mũ", offset: 1 },
        { text: "_{}", displayText: "_{} — Chỉ số dưới", offset: 1 },
        { text: "\\sum_{i=1}^{n}", displayText: "\\sum — Tổng sigma", offset: 0 },
        { text: "\\prod_{i=1}^{n}", displayText: "\\prod — Tích", offset: 0 },
        { text: "\\int_{a}^{b}", displayText: "\\int — Tích phân", offset: 0 },
        { text: "\\lim_{x \\to \\infty}", displayText: "\\lim — Giới hạn", offset: 0 },
        { text: "\\infty", displayText: "\\infty — Vô cực", offset: 0 },
        { text: "\\le", displayText: "\\le — Nhỏ hơn hoặc bằng (<=)", offset: 0 },
        { text: "\\ge", displayText: "\\ge — Lớn hơn hoặc bằng (>=)", offset: 0 },
        { text: "\\neq", displayText: "\\neq — Khác (!=)", offset: 0 },
        { text: "\\equiv", displayText: "\\equiv — Đồng dư", offset: 0 },
        { text: "\\pmod{}", displayText: "\\pmod{} — Modulo", offset: 1 },
        { text: "\\mid", displayText: "\\mid — Chia hết cho", offset: 0 },
        { text: "\\nmid", displayText: "\\nmid — Không chia hết cho", offset: 0 },
        { text: "\\Rightarrow", displayText: "\\Rightarrow — Suy ra (=>)", offset: 0 },
        { text: "\\Leftrightarrow", displayText: "\\Leftrightarrow — Tương đương (<=>)", offset: 0 },
        { text: "\\forall", displayText: "\\forall — Với mọi", offset: 0 },
        { text: "\\exists", displayText: "\\exists — Tồn tại", offset: 0 },
        { text: "\\in", displayText: "\\in — Thuộc tập hợp", offset: 0 },
        { text: "\\notin", displayText: "\\notin — Không thuộc", offset: 0 },
        { text: "\\subset", displayText: "\\subset — Tập con", offset: 0 },
        { text: "\\cup", displayText: "\\cup — Phép hợp", offset: 0 },
        { text: "\\cap", displayText: "\\cap — Phép giao", offset: 0 },
        { text: "\\emptyset", displayText: "\\emptyset — Tập rỗng", offset: 0 },
        { text: "\\mathbb{R}", displayText: "\\mathbb{R} — Tập số thực R", offset: 0 },
        { text: "\\mathbb{N}", displayText: "\\mathbb{N} — Tập số tự nhiên N", offset: 0 },
        { text: "\\mathbb{Z}", displayText: "\\mathbb{Z} — Tập số nguyên Z", offset: 0 },
        { text: "\\mathbb{Q}", displayText: "\\mathbb{Q} — Tập số hữu tỉ Q", offset: 0 },
        { text: "\\mathbb{C}", displayText: "\\mathbb{C} — Tập số phức C", offset: 0 },
        { text: "\\alpha", displayText: "\\alpha — Alpha", offset: 0 },
        { text: "\\beta", displayText: "\\beta — Beta", offset: 0 },
        { text: "\\gamma", displayText: "\\gamma — Gamma", offset: 0 },
        { text: "\\delta", displayText: "\\delta — Delta", offset: 0 },
        { text: "\\Delta", displayText: "\\Delta — Delta hoa", offset: 0 },
        { text: "\\pi", displayText: "\\pi — Pi", offset: 0 },
        { text: "\\varphi", displayText: "\\varphi — Phi", offset: 0 },
        { text: "\\sigma", displayText: "\\sigma — Sigma", offset: 0 },
        { text: "\\omega", displayText: "\\omega — Omega", offset: 0 },
        { text: "\\Omega", displayText: "\\Omega — Omega hoa", offset: 0 },
        { text: "\\vec{}", displayText: "\\vec{} — Vectơ", offset: 1 },
        { text: "\\overline{}", displayText: "\\overline{} — Đoạn thẳng", offset: 1 },
        { text: "\\binom{n}{k}", displayText: "\\binom{n}{k} — Hệ số nhị thức / Tổ hợp", offset: 0 },
        { text: "\\gcd(,)", displayText: "\\gcd(,) — Ước chung lớn nhất", offset: 2 },
        { text: "\\lfloor \\rfloor", displayText: "\\lfloor \\rfloor — Phần nguyên dưới", offset: 8 },
        { text: "\\lceil \\rceil", displayText: "\\lceil \\rceil — Phần nguyên trên", offset: 7 },
        { text: "\\begin{cases}\n  & \\\\\n  &\n\\end{cases}", displayText: "\\begin{cases} — Hệ phương trình", offset: 22 },
        { text: "\\begin{pmatrix}\n  & \\\\\n  &\n\\end{pmatrix}", displayText: "\\begin{pmatrix} — Ma trận ngoặc tròn", offset: 19 },
        { text: "\\begin{align*}\n  \n\\end{align*}", displayText: "\\begin{align*} — Căn lề nhiều dòng", offset: 13 },
        { text: "\\textbf{}", displayText: "\\textbf{} — Chữ in đậm", offset: 1 },
        { text: "\\textit{}", displayText: "\\textit{} — Chữ in nghiêng", offset: 1 },
        { text: "\\textbf{Bài toán.} ", displayText: "Bài toán. — Đề mục bài toán", offset: 0 },
        { text: "\\textbf{Lời giải.} ", displayText: "Lời giải. — Đề mục lời giải", offset: 0 },
        { text: "\\textbf{Bổ đề.} ", displayText: "Bổ đề. — Đề mục bổ đề", offset: 0 },
        { text: "\\textbf{Định lý.} ", displayText: "Định lý. — Đề mục định lý", offset: 0 }
    ];

    // Bắt và lưu vết ô nhập liệu / ô bình luận người dùng đang tương tác
    document.addEventListener('contextmenu', (e) => {
        const t = e.target;
        if (t && (t.isContentEditable || t.tagName === 'TEXTAREA' || t.tagName === 'INPUT' || t.closest('[contenteditable="true"]'))) {
            lastActiveEditable = t.closest('[contenteditable="true"]') || t;
        }
    }, true);

    document.addEventListener('focusin', (e) => {
        const t = e.target;
        if (t && (t.isContentEditable || t.tagName === 'TEXTAREA' || t.tagName === 'INPUT' || t.closest('[contenteditable="true"]'))) {
            lastActiveEditable = t.closest('[contenteditable="true"]') || t;
        }
    }, true);

    /**
     * Tạo hoặc lấy Shadow DOM Container
     */
    function ensureModalHost() {
        if (!modalHost || !document.body.contains(modalHost)) {
            modalHost = document.createElement('div');
            modalHost.id = 'smp-latex-modal-host';
            modalHost.style.position = 'fixed';
            modalHost.style.top = '0';
            modalHost.style.left = '0';
            modalHost.style.width = '0';
            modalHost.style.height = '0';
            modalHost.style.zIndex = '2147483647';
            document.body.appendChild(modalHost);

            shadowRoot = modalHost.attachShadow({ mode: 'open' });

            // Nạp KaTeX CSS vào bên trong Shadow DOM
            const katexCssLink = document.createElement('link');
            katexCssLink.rel = 'stylesheet';
            katexCssLink.href = chrome.runtime.getURL('katex/katex.min.css');
            shadowRoot.appendChild(katexCssLink);

            // Nạp Modal Stylesheet
            const style = document.createElement('style');
            style.textContent = getModalStyles();
            shadowRoot.appendChild(style);
        }
        return shadowRoot;
    }

    /**
     * CSS đóng gói bên trong Shadow DOM (Bao gồm chế độ Sáng và Tối)
     */
    function getModalStyles() {
        return `
            * {
                box-sizing: border-box;
                margin: 0;
                padding: 0;
            }
            :host {
                font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
                font-size: 14px;
                line-height: 1.6;
            }
            .smp-backdrop {
                position: fixed;
                top: 0;
                left: 0;
                width: 100vw;
                height: 100vh;
                background: transparent;
                backdrop-filter: none;
                display: flex;
                align-items: center;
                justify-content: center;
                opacity: 0;
                pointer-events: none;
                transition: opacity 0.2s ease;
            }
            .smp-backdrop.active {
                opacity: 1;
                pointer-events: none; /* Giữ none để trang phía sau nhận tương tác xem đề, bôi đen */
            }

            /* --- GIAO DIỆN HỘP THOẠI & HIỆU ỨNG CHUYỂN MƯỢT MÀ --- */
            .smp-dialog {
                pointer-events: auto; /* Nhận tương tác chuột và bàn phím riêng cho hộp thoại */
                position: absolute;
                width: 860px;
                height: 620px;
                min-width: 520px;
                min-height: 400px;
                max-width: 98vw;
                max-height: 98vh;
                resize: both; /* Cho phép người dùng kéo giãn chỉnh kích thước tùy ý */
                background: #0f1416;
                color: #e2e8f0;
                border-radius: 12px;
                border: 1px solid rgba(92, 225, 230, 0.25);
                box-shadow: 0 20px 50px rgba(0, 0, 0, 0.7), 0 0 24px rgba(92, 225, 230, 0.12);
                display: flex;
                flex-direction: column;
                overflow: hidden;
                transform: scale(0.96) translateY(8px);
                transition: transform 0.22s cubic-bezier(0.16, 1, 0.3, 1),
                            opacity 0.2s ease,
                            background-color 0.35s cubic-bezier(0.4, 0, 0.2, 1),
                            color 0.35s cubic-bezier(0.4, 0, 0.2, 1),
                            border-color 0.35s cubic-bezier(0.4, 0, 0.2, 1),
                            box-shadow 0.35s cubic-bezier(0.4, 0, 0.2, 1);
            }
            .smp-backdrop.active .smp-dialog {
                transform: scale(1) translateY(0);
            }

            /* Chuyển đổi màu sắc lan dần mượt mà trên tất cả thành phần */
            .smp-dialog,
            .smp-header,
            .smp-body,
            .smp-footer,
            .smp-pane-header,
            .smp-pane-title,
            .smp-textarea,
            .smp-preview-box,
            .smp-snippet-toolbar,
            .smp-snip-btn,
            .smp-tab-btn,
            .smp-action-btn,
            .smp-raw-textarea,
            .smp-translate-view,
            .smp-badge,
            .smp-snip-label,
            .smp-close-btn,
            .smp-switch-track,
            .smp-switch-handle {
                transition: background-color 0.35s cubic-bezier(0.4, 0, 0.2, 1),
                            color 0.35s cubic-bezier(0.4, 0, 0.2, 1),
                            border-color 0.35s cubic-bezier(0.4, 0, 0.2, 1),
                            box-shadow 0.35s cubic-bezier(0.4, 0, 0.2, 1);
            }

            .smp-header {
                display: flex;
                align-items: center;
                justify-content: space-between;
                padding: 10px 16px;
                background: #161d20;
                border-bottom: 1px solid rgba(255, 255, 255, 0.08);
                cursor: move;
                user-select: none;
            }
            .smp-title-wrap {
                display: flex;
                align-items: center;
                gap: 8px;
            }
            .smp-badge {
                font-size: 10px;
                font-weight: 700;
                letter-spacing: 0.5px;
                text-transform: uppercase;
                background: rgba(92, 225, 230, 0.15);
                color: #5ce1e6;
                padding: 2px 7px;
                border-radius: 4px;
                border: 1px solid rgba(92, 225, 230, 0.3);
            }
            .smp-title {
                font-size: 13px;
                font-weight: 600;
                color: #f8fafc;
            }
            .smp-header-actions {
                display: flex;
                align-items: center;
                gap: 6px;
            }
            .smp-tab-btn {
                background: transparent;
                border: 1px solid rgba(255, 255, 255, 0.12);
                color: #94a3b8;
                padding: 4px 8px;
                min-width: 30px;
                height: 26px;
                border-radius: 6px;
                cursor: pointer;
                display: inline-flex;
                align-items: center;
                justify-content: center;
                transition: all 0.15s ease;
            }
            .smp-tab-btn svg {
                margin: 0 !important;
            }
            .smp-tab-btn.active {
                background: rgba(92, 225, 230, 0.2);
                border-color: #5ce1e6;
                color: #5ce1e6;
            }
            .smp-tab-btn:hover:not(.active) {
                background: rgba(255, 255, 255, 0.05);
                color: #e2e8f0;
            }
            .smp-tab-btn.smp-tab-latex {
                padding: 3px 8px;
                min-width: 44px;
            }
            .smp-latex-logo {
                font-family: 'KaTeX_Main', 'Times New Roman', Georgia, serif;
                font-size: 13px;
                font-weight: 700;
                letter-spacing: 0.02em;
                display: inline-flex;
                align-items: baseline;
                line-height: 1;
                user-select: none;
            }
            .smp-latex-logo .tex-bs {
                opacity: 0.85;
                margin-right: 1px;
                font-family: 'JetBrains Mono', Consolas, monospace;
                font-weight: 600;
                font-size: 12px;
            }
            .smp-latex-logo .tex-a {
                font-size: 0.74em;
                text-transform: uppercase;
                transform: translateY(-0.22em);
                margin-left: -0.1em;
                margin-right: -0.05em;
                display: inline-block;
            }
            .smp-latex-logo .tex-e {
                font-size: 0.85em;
                text-transform: uppercase;
                transform: translateY(0.18em);
                margin-left: -0.08em;
                margin-right: -0.04em;
                display: inline-block;
            }

            /* --- CẦN GẠT CHUYỂN SÁNG / TỐI (TỐI GIẢN KHÔNG DÙNG ICON) --- */
            .smp-theme-switch {
                position: relative;
                display: inline-flex;
                align-items: center;
                width: 38px;
                height: 20px;
                cursor: pointer;
                user-select: none;
                margin: 0 4px;
            }
            .smp-theme-switch input {
                opacity: 0;
                width: 0;
                height: 0;
                position: absolute;
                margin: 0;
                pointer-events: none;
            }
            .smp-switch-track {
                position: absolute;
                top: 0;
                left: 0;
                right: 0;
                bottom: 0;
                background: #cbd5e1;
                border: 1px solid #94a3b8;
                border-radius: 20px;
                box-sizing: border-box;
                transition: background-color 0.3s ease, border-color 0.3s ease;
            }
            .smp-switch-handle {
                position: absolute;
                top: 2px;
                left: 2px;
                width: 14px;
                height: 14px;
                border-radius: 50%;
                background: #ffffff;
                box-shadow: 0 1px 3px rgba(0, 0, 0, 0.3);
                transition: transform 0.28s cubic-bezier(0.34, 1.4, 0.64, 1),
                            background-color 0.28s ease,
                            box-shadow 0.28s ease;
                z-index: 2;
            }

            /* Khi gạt sang (checked = Tối) */
            .smp-theme-switch input:checked + .smp-switch-track {
                background: #0d161a;
                border-color: rgba(92, 225, 230, 0.55);
                box-shadow: 0 0 8px rgba(92, 225, 230, 0.22);
            }
            .smp-theme-switch input:checked + .smp-switch-track .smp-switch-handle {
                transform: translateX(18px);
                background: #5ce1e6;
                box-shadow: 0 0 8px rgba(92, 225, 230, 0.65);
            }

            .smp-close-btn {
                background: transparent;
                border: none;
                color: #94a3b8;
                font-size: 17px;
                line-height: 1;
                cursor: pointer;
                padding: 4px 8px;
                border-radius: 4px;
                display: flex;
                align-items: center;
                justify-content: center;
            }
            .smp-close-btn:hover {
                background: rgba(239, 68, 68, 0.2);
                color: #ef4444;
            }

            .smp-body {
                padding: 12px 16px;
                overflow-y: auto;
                flex: 1;
                min-height: 0;
                background: #0b1012;
                display: flex;
                flex-direction: column;
                gap: 10px;
            }
            .smp-body::-webkit-scrollbar {
                width: 6px;
                height: 6px;
            }
            .smp-body::-webkit-scrollbar-thumb {
                background: rgba(255, 255, 255, 0.15);
                border-radius: 3px;
            }

            /* --- THANH NHÓM KÝ HIỆU TOÁN CHUẨN SMP LATEX EDITOR --- */
            .smp-snippet-toolbar {
                display: flex;
                flex-direction: column;
                gap: 6px;
                padding: 8px 12px;
                background: #141b1e;
                border: 1px solid rgba(255, 255, 255, 0.08);
                border-radius: 8px;
                max-height: 145px;
                overflow-y: auto;
            }
            .smp-snip-row {
                display: flex;
                align-items: center;
                gap: 6px;
                flex-wrap: wrap;
            }
            .smp-snip-label {
                font-size: 10px;
                font-family: 'JetBrains Mono', monospace;
                letter-spacing: 0.8px;
                text-transform: uppercase;
                color: #5ce1e6;
                opacity: 0.85;
                min-width: 90px;
                margin-right: 4px;
            }
            .smp-snip-btns {
                display: flex;
                flex-wrap: wrap;
                gap: 4px;
                flex: 1;
            }
            .smp-snip-btn {
                background: rgba(92, 225, 230, 0.08);
                border: 1px solid rgba(92, 225, 230, 0.18);
                color: #e2e8f0;
                font-size: 11px;
                padding: 3px 8px;
                border-radius: 5px;
                cursor: pointer;
                transition: all 0.15s ease;
                white-space: nowrap;
                font-family: "Times New Roman", serif;
                line-height: 1.2;
            }
            .smp-snip-btn:hover {
                background: rgba(92, 225, 230, 0.22);
                border-color: #5ce1e6;
                color: #5ce1e6;
                transform: translateY(-1px);
            }
            .smp-snip-btn .katex {
                font-size: 0.95em;
            }

            /* --- GIAO DIỆN SOẠN THẢO SONG SONG (2 CỘT) --- */
            #smp-panel-compose {
                display: flex;
                flex-direction: column;
                gap: 8px;
                flex: 1;
                min-height: 0;
            }
            .smp-workspace {
                display: grid;
                grid-template-columns: 1fr 1fr;
                gap: 12px;
                flex: 1;
                min-height: 200px;
                position: relative;
            }
            @media (max-width: 720px) {
                .smp-workspace { grid-template-columns: 1fr; }
            }
            .smp-pane {
                display: flex;
                flex-direction: column;
                min-width: 0;
                height: 100%;
                min-height: 0;
                position: relative;
            }
            .smp-pane-header {
                display: flex;
                align-items: center;
                justify-content: space-between;
                padding: 6px 10px;
                background: #141c20;
                border: 1px solid rgba(92, 225, 230, 0.15);
                border-bottom: none;
                border-radius: 8px 8px 0 0;
            }
            .smp-pane-title {
                font-family: 'JetBrains Mono', monospace;
                font-size: 10px;
                letter-spacing: 1px;
                text-transform: uppercase;
                color: #5ce1e6;
            }
            .smp-pane-meta {
                font-size: 10px;
                color: #64748b;
                font-family: 'JetBrains Mono', monospace;
            }
            .smp-editor-box {
                position: relative;
                flex: 1;
                display: flex;
                flex-direction: column;
            }
            .smp-textarea {
                width: 100%;
                flex: 1;
                height: 100%;
                min-height: 160px;
                background: #070a0b;
                border: 1px solid rgba(92, 225, 230, 0.15);
                border-radius: 0 0 8px 8px;
                color: #a5f3fc;
                font-family: 'JetBrains Mono', Consolas, Monaco, monospace;
                font-size: 13px;
                padding: 10px;
                outline: none;
                resize: none;
                box-sizing: border-box;
                line-height: 1.6;
            }
            .smp-textarea:focus {
                border-color: #5ce1e6;
            }
            .smp-preview-box {
                width: 100%;
                flex: 1;
                height: 100%;
                min-height: 160px;
                overflow-y: auto;
                background: #091218;
                border: 1px solid rgba(92, 225, 230, 0.22);
                border-radius: 0 0 8px 8px;
                padding: 14px 18px;
                color: #e2e8f0;
                font-family: "Times New Roman", Times, Georgia, serif;
                font-size: 16px;
                line-height: 1.95;
                letter-spacing: 0.015em;
                white-space: normal;
                word-break: break-word;
                box-shadow: inset 0 2px 8px rgba(0, 0, 0, 0.4);
            }
            .smp-preview-box b, .smp-preview-box strong {
                color: #5ce1e6;
                font-weight: 700;
            }
            .smp-preview-box h2 {
                color: #f8fafc;
                font-family: "Times New Roman", serif;
                text-align: center;
                margin: 10px 0;
                font-size: 1.3rem;
            }
            .smp-preview-box h3 {
                color: #5ce1e6;
                font-family: "Times New Roman", serif;
                border-left: 3px solid #5ce1e6;
                padding-left: 8px;
                margin: 14px 0 8px 0;
                font-size: 1.1rem;
            }
            .smp-preview-box h4 {
                color: #38bdf8;
                font-family: "Times New Roman", serif;
                margin: 10px 0 6px 0;
                font-size: 1.02rem;
            }
            .smp-preview-box h5 {
                color: #94a3b8;
                font-family: "Times New Roman", serif;
                margin: 8px 0 4px 0;
                font-size: 0.95rem;
            }
            .smp-preview-box .latex-fbox {
                display: inline-block;
                border: 1.5px solid #5ce1e6;
                color: #5ce1e6;
                padding: 2px 7px;
                border-radius: 4px;
                margin: 2px 4px;
                line-height: normal;
                vertical-align: middle;
            }
            .smp-preview-box .latex-bullet {
                color: #5ce1e6;
                font-weight: bold;
                margin-right: 6px;
            }
            .smp-preview-box u {
                text-underline-offset: 3px;
            }

            /* --- GỢI Ý TỰ ĐỘNG (AUTOCOMPLETE POPUP) --- */
            .smp-autocomplete-popup {
                position: absolute;
                top: 40px;
                left: 10px;
                max-width: 380px;
                max-height: 200px;
                overflow-y: auto;
                background: #141c20;
                border: 1px solid #5ce1e6;
                box-shadow: 0 8px 24px rgba(0, 0, 0, 0.7);
                border-radius: 6px;
                z-index: 50;
                display: none;
            }
            .smp-autocomplete-popup.show {
                display: block;
            }
            .smp-hint-item {
                padding: 6px 10px;
                font-size: 12px;
                font-family: 'JetBrains Mono', monospace;
                color: #cbd5e1;
                cursor: pointer;
                display: flex;
                align-items: center;
                justify-content: space-between;
                border-bottom: 1px solid rgba(255, 255, 255, 0.05);
            }
            .smp-hint-item:hover, .smp-hint-item.active {
                background: rgba(92, 225, 230, 0.2);
                color: #5ce1e6;
            }
            .smp-hint-badge {
                font-size: 10px;
                opacity: 0.7;
                margin-left: 8px;
            }

            /* --- TAB BIÊN DỊCH & MÃ NGUỒN --- */
            #smp-panel-translate {
                display: flex;
                flex-direction: column;
                gap: 8px;
                flex: 1;
                min-height: 0;
            }
            .smp-translate-view {
                font-family: "Times New Roman", Times, Georgia, serif;
                color: #e2e8f0;
                font-size: 16px;
                line-height: 1.95;
                letter-spacing: 0.015em;
                white-space: normal;
                word-break: break-word;
                flex: 1;
                min-height: 150px;
                padding: 14px 18px;
                background: #091218;
                border: 1px solid rgba(92, 225, 230, 0.22);
                border-radius: 8px;
                overflow-y: auto;
            }
            .smp-translate-raw-box {
                display: flex;
                flex-direction: column;
                flex: none;
                position: relative;
            }
            .smp-translate-raw-box .smp-pane-header {
                border-radius: 8px 8px 0 0;
            }
            .smp-translate-view b, .smp-translate-view strong {
                color: #5ce1e6;
                font-weight: 700;
            }
            .smp-translate-view h2 {
                color: #f8fafc;
                font-family: "Times New Roman", serif;
                text-align: center;
                margin: 10px 0;
            }
            .smp-translate-view h3 {
                color: #5ce1e6;
                font-family: "Times New Roman", serif;
                border-left: 3px solid #5ce1e6;
                padding-left: 8px;
                margin: 14px 0 8px 0;
            }
            .smp-translate-view h4 {
                color: #38bdf8;
                font-family: "Times New Roman", serif;
                margin: 10px 0 6px 0;
            }
            .smp-translate-view .latex-fbox {
                display: inline-block;
                border: 1.5px solid #5ce1e6;
                color: #5ce1e6;
                padding: 2px 7px;
                border-radius: 4px;
                margin: 2px 4px;
                line-height: normal;
                vertical-align: middle;
            }
            .smp-translate-view .latex-bullet {
                color: #5ce1e6;
                font-weight: bold;
                margin-right: 6px;
            }
            .latex-par-spacer {
                height: 12px;
            }
            .latex-center {
                text-align: center;
                margin: 8px 0;
            }
            .latex-flushleft {
                text-align: left;
                margin: 8px 0;
            }
            .latex-flushright {
                text-align: right;
                margin: 8px 0;
            }
            .latex-table-wrapper {
                width: 100%;
                overflow-x: auto;
                margin: 10px 0;
                display: flex;
                justify-content: center;
            }
            .latex-table {
                border-collapse: collapse;
                margin: 0 auto;
                font-family: inherit;
                font-size: 0.95em;
            }
            .latex-table td, .latex-table th {
                padding: 5px 12px;
                vertical-align: middle;
                line-height: 1.5;
            }
            .latex-table td.border-top, .latex-table tr.border-top td { border-top: 1px solid currentColor; }
            .latex-table td.border-bottom, .latex-table tr.border-bottom td { border-bottom: 1px solid currentColor; }
            .latex-table td.border-left { border-left: 1px solid currentColor; }
            .latex-table td.border-right { border-right: 1px solid currentColor; }
            .smp-raw-textarea {
                width: 100%;
                height: 115px;
                min-height: 75px;
                background: #070a0b;
                border: 1px solid rgba(92, 225, 230, 0.15);
                border-radius: 0 0 8px 8px;
                color: #a5f3fc;
                font-family: 'JetBrains Mono', Consolas, Monaco, monospace;
                font-size: 13px;
                padding: 10px;
                outline: none;
                resize: vertical;
                box-sizing: border-box;
                line-height: 1.6;
            }
            .smp-raw-textarea:focus {
                border-color: #5ce1e6;
            }

            /* --- ĐỊNH DẠNG KATEX --- */
            .katex {
                font-size: 1.05em;
                color: inherit;
            }
            .katex-display {
                margin: 0.8em 0;
                overflow-x: auto;
                overflow-y: hidden;
                padding: 6px 0;
            }

            /* --- CHÂN TRANG (FOOTER ACTIONS) --- */
            .smp-footer {
                display: flex;
                align-items: center;
                justify-content: space-between;
                padding: 8px 16px;
                background: #141a1c;
                border-top: 1px solid rgba(255, 255, 255, 0.08);
                font-size: 11px;
                color: #64748b;
            }
            .smp-footer-left {
                display: flex;
                align-items: center;
                gap: 8px;
            }
            /* Thiết kế bộ chọn Model AI kiểu Segmented Pill */
            .smp-model-pill {
                display: inline-flex;
                align-items: center;
                background: rgba(255, 255, 255, 0.06);
                border: 1px solid rgba(255, 255, 255, 0.12);
                border-radius: 14px;
                padding: 2px;
                gap: 2px;
            }
            .smp-model-btn {
                background: transparent;
                border: none;
                color: #94a3b8;
                font-size: 11px;
                font-weight: 600;
                padding: 2px 10px;
                border-radius: 10px;
                cursor: pointer;
                transition: all 0.2s ease;
                line-height: 1.3;
                letter-spacing: 0.3px;
                font-family: inherit;
            }
            .smp-model-btn.active {
                background: #0ea5e9;
                color: #ffffff;
                box-shadow: 0 1px 4px rgba(14, 165, 233, 0.4);
            }
            .smp-model-btn:hover:not(.active) {
                color: #e2e8f0;
                background: rgba(255, 255, 255, 0.08);
            }
            .smp-footer-actions {
                display: flex;
                align-items: center;
                gap: 8px;
            }
            /* Tinh chỉnh nút hành động bên dưới: chỉ giữ icon tinh gọn */
            .smp-action-btn {
                background: rgba(92, 225, 230, 0.12);
                border: 1px solid rgba(92, 225, 230, 0.3);
                color: #5ce1e6;
                padding: 6px 10px;
                min-width: 32px;
                height: 30px;
                border-radius: 6px;
                font-size: 12px;
                font-weight: 500;
                cursor: pointer;
                transition: all 0.15s ease;
                display: inline-flex;
                align-items: center;
                justify-content: center;
            }
            .smp-action-btn:hover {
                background: rgba(92, 225, 230, 0.25);
                transform: translateY(-1px);
            }
            .smp-action-btn:active {
                transform: translateY(0);
            }
            .smp-action-btn.btn-primary {
                background: #0ea5e9;
                border-color: #38bdf8;
                color: #ffffff;
                font-weight: 600;
            }
            .smp-action-btn.btn-primary:hover {
                background: #0284c7;
            }

            /* --- TOAST THÔNG BÁO --- */
            .smp-toast {
                position: absolute;
                bottom: 50px;
                left: 50%;
                transform: translateX(-50%) translateY(10px);
                background: rgba(15, 23, 42, 0.96);
                border: 1px solid rgba(92, 225, 230, 0.5);
                color: #5ce1e6;
                padding: 8px 18px;
                border-radius: 8px;
                font-size: 12px;
                box-shadow: 0 8px 24px rgba(0,0,0,0.6);
                opacity: 0;
                pointer-events: none;
                transition: all 0.2s ease;
                z-index: 100;
                white-space: nowrap;
            }
            .smp-toast.show {
                opacity: 1;
                transform: translateX(-50%) translateY(0);
            }

            /* ==============================================================
             * CHẾ ĐỘ SÁNG (LIGHT MODE)
             * ============================================================== */
            .smp-dialog.light-theme {
                background: #ffffff;
                color: #1e293b;
                border-color: rgba(0, 0, 0, 0.15);
                box-shadow: 0 20px 50px rgba(0, 0, 0, 0.18), 0 0 20px rgba(0, 158, 179, 0.1);
            }
            .smp-dialog.light-theme .smp-header {
                background: #f8fafc;
                border-bottom-color: #e2e8f0;
            }
            .smp-dialog.light-theme .smp-badge {
                background: rgba(0, 158, 179, 0.1);
                color: #009eb3;
                border-color: rgba(0, 158, 179, 0.3);
            }
            .smp-dialog.light-theme .smp-title {
                color: #0f172a;
            }
            .smp-dialog.light-theme .smp-tab-btn {
                border-color: #cbd5e1;
                color: #64748b;
            }
            .smp-dialog.light-theme .smp-tab-btn.active {
                background: rgba(0, 158, 179, 0.12);
                border-color: #009eb3;
                color: #009eb3;
            }
            .smp-dialog.light-theme .smp-tab-btn:hover:not(.active) {
                background: #f1f5f9;
                color: #0f172a;
            }
            .smp-dialog.light-theme .smp-switch-track {
                background: #e2e8f0;
                border-color: #cbd5e1;
            }
            .smp-dialog.light-theme .smp-theme-switch input:checked + .smp-switch-track {
                background: #0d161a;
                border-color: rgba(92, 225, 230, 0.55);
            }
            .smp-dialog.light-theme .smp-body {
                background: #f8fafc;
            }
            .smp-dialog.light-theme .smp-snippet-toolbar {
                background: #ffffff;
                border-color: #e2e8f0;
            }
            .smp-dialog.light-theme .smp-snip-label {
                color: #009eb3;
            }
            .smp-dialog.light-theme .smp-snip-btn {
                background: #f1f5f9;
                border-color: #e2e8f0;
                color: #334155;
            }
            .smp-dialog.light-theme .smp-snip-btn:hover {
                background: rgba(0, 158, 179, 0.15);
                border-color: #009eb3;
                color: #009eb3;
            }
            .smp-dialog.light-theme .smp-pane-header {
                background: #f1f5f9;
                border-color: #cbd5e1;
            }
            .smp-dialog.light-theme .smp-pane-title {
                color: #009eb3;
            }
            .smp-dialog.light-theme .smp-textarea {
                background: #ffffff;
                border-color: #cbd5e1;
                color: #0f172a;
            }
            .smp-dialog.light-theme .smp-textarea:focus {
                border-color: #009eb3;
            }
            .smp-dialog.light-theme .smp-preview-box,
            .smp-dialog.light-theme .smp-translate-view {
                background: #ffffff;
                border-color: #cbd5e1;
                color: #1e293b;
                box-shadow: inset 0 1px 4px rgba(0, 0, 0, 0.05);
            }
            .smp-dialog.light-theme .smp-preview-box b,
            .smp-dialog.light-theme .smp-preview-box strong,
            .smp-dialog.light-theme .smp-translate-view b,
            .smp-dialog.light-theme .smp-translate-view strong {
                color: #0f172a;
                font-weight: 700;
            }
            .smp-dialog.light-theme .smp-preview-box h2,
            .smp-dialog.light-theme .smp-translate-view h2 {
                color: #0f172a;
            }
            .smp-dialog.light-theme .smp-preview-box h3,
            .smp-dialog.light-theme .smp-translate-view h3 {
                color: #009eb3;
                border-left-color: #009eb3;
            }
            .smp-dialog.light-theme .smp-preview-box h4,
            .smp-dialog.light-theme .smp-translate-view h4 {
                color: #0284c7;
            }
            .smp-dialog.light-theme .smp-preview-box h5,
            .smp-dialog.light-theme .smp-translate-view h5 {
                color: #475569;
            }
            .smp-dialog.light-theme .smp-preview-box .latex-fbox,
            .smp-dialog.light-theme .smp-translate-view .latex-fbox {
                border-color: #009eb3;
                color: #009eb3;
            }
            .smp-dialog.light-theme .smp-preview-box .latex-bullet,
            .smp-dialog.light-theme .smp-translate-view .latex-bullet {
                color: #009eb3;
            }
            .smp-dialog.light-theme .smp-preview-box .katex,
            .smp-dialog.light-theme .smp-translate-view .katex {
                color: #0f172a;
            }
            .smp-dialog.light-theme .smp-raw-textarea {
                background: #ffffff;
                border-color: #cbd5e1;
                color: #0f172a;
            }
            .smp-dialog.light-theme .smp-raw-textarea:focus {
                border-color: #009eb3;
            }
            .smp-dialog.light-theme .smp-autocomplete-popup {
                background: #ffffff;
                border-color: #009eb3;
                box-shadow: 0 8px 24px rgba(0,0,0,0.15);
            }
            .smp-dialog.light-theme .smp-hint-item {
                color: #334155;
                border-bottom-color: #f1f5f9;
            }
            .smp-dialog.light-theme .smp-hint-item:hover,
            .smp-dialog.light-theme .smp-hint-item.active {
                background: rgba(0, 158, 179, 0.12);
                color: #009eb3;
            }
            .smp-dialog.light-theme .smp-footer {
                background: #f8fafc;
                border-top-color: #e2e8f0;
            }
            .smp-dialog.light-theme .smp-model-pill {
                background: #e2e8f0;
                border-color: #cbd5e1;
            }
            .smp-dialog.light-theme .smp-model-btn {
                color: #64748b;
            }
            .smp-dialog.light-theme .smp-model-btn.active {
                background: #009eb3;
                color: #ffffff;
                box-shadow: 0 1px 4px rgba(0, 158, 179, 0.3);
            }
            .smp-dialog.light-theme .smp-model-btn:hover:not(.active) {
                color: #0f172a;
                background: #f1f5f9;
            }
            .smp-dialog.light-theme .smp-action-btn {
                background: rgba(0, 158, 179, 0.09);
                border-color: rgba(0, 158, 179, 0.3);
                color: #009eb3;
            }
            .smp-dialog.light-theme .smp-action-btn:hover {
                background: rgba(0, 158, 179, 0.2);
            }
            .smp-dialog.light-theme .smp-action-btn.btn-primary {
                background: #009eb3;
                border-color: #008799;
                color: #ffffff;
            }
            .smp-dialog.light-theme .smp-toast {
                background: #0f172a;
                color: #38bdf8;
                border-color: #38bdf8;
            }
        `;
    }

    /**
     * Tạo markup hộp thoại hoàn chỉnh
     */
    function createModalDom() {
        const root = ensureModalHost();
        let backdrop = root.querySelector('.smp-backdrop');

        if (!backdrop) {
            backdrop = document.createElement('div');
            backdrop.className = 'smp-backdrop';
            backdrop.innerHTML = `
                <div class="smp-dialog" id="smp-dialog">
                    <div class="smp-header" id="smp-drag-header">
                        <div class="smp-title-wrap">
                            <span class="smp-badge">SMP</span>
                            <span class="smp-title" id="smp-modal-title"></span>
                        </div>
                        <div class="smp-header-actions">
                            <button class="smp-tab-btn" id="smp-btn-tab-compose" title="Soạn Thảo (Live Editor)">
                                <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M17 3a2.85 2.83 0 1 1 4 4L7.5 20.5 2 22l1.5-5.5Z"/><path d="m15 5 4 4"/></svg>
                            </button>
                            <button class="smp-tab-btn smp-tab-latex" id="smp-btn-tab-translate" title="Biên Dịch & Mã \LaTeX">
                                <span class="smp-latex-logo"><span class="tex-bs">\</span>L<span class="tex-a">a</span>T<span class="tex-e">e</span>X</span>
                            </button>
                            <label class="smp-theme-switch" title="Chuyển chế độ Sáng / Tối" id="smp-theme-toggle-label">
                                <input type="checkbox" id="smp-theme-toggle-input" aria-label="Chuyển chế độ Sáng / Tối">
                                <span class="smp-switch-track">
                                    <span class="smp-switch-handle"></span>
                                </span>
                            </label>
                            <button class="smp-close-btn" id="smp-btn-close" title="Đóng (Esc)">✕</button>
                        </div>
                    </div>

                    <div class="smp-body">
                        <!-- 1. GIAO DIỆN SOẠN THẢO SONG SONG VỚI BỘ KÝ HIỆU CHUẨN SMP -->
                        <div id="smp-panel-compose" style="display: flex; flex-direction: column; gap: 8px;">
                            <!-- Thanh Ký Hiệu Đầy Đủ 8 Nhóm Từ SMP LaTeX Editor -->
                            <div class="smp-snippet-toolbar" id="smp-snippet-toolbar">
                                <div class="smp-snip-row">
                                    <span class="smp-snip-label">Phân số & Căn</span>
                                    <div class="smp-snip-btns">
                                        <button class="smp-snip-btn" data-snip="\\frac{a}{b}">$\\frac{a}{b}$</button>
                                        <button class="smp-snip-btn" data-snip="\\sqrt{x}">$\\sqrt{x}$</button>
                                        <button class="smp-snip-btn" data-snip="\\sqrt[n]{x}">$\\sqrt[n]{x}$</button>
                                        <button class="smp-snip-btn" data-snip="^{n}">$x^{n}$</button>
                                        <button class="smp-snip-btn" data-snip="_{n}">$x_{n}$</button>
                                    </div>
                                </div>
                                <div class="smp-snip-row">
                                    <span class="smp-snip-label">Tổng & Tích phân</span>
                                    <div class="smp-snip-btns">
                                        <button class="smp-snip-btn" data-snip="\\sum_{i=1}^{n}">$\\sum_{i=1}^{n}$</button>
                                        <button class="smp-snip-btn" data-snip="\\prod_{i=1}^{n}">$\\prod_{i=1}^{n}$</button>
                                        <button class="smp-snip-btn" data-snip="\\int_{a}^{b}">$\\int_{a}^{b}$</button>
                                        <button class="smp-snip-btn" data-snip="\\lim_{x \\to \\infty}">lim</button>
                                        <button class="smp-snip-btn" data-snip="\\infty">$\\infty$</button>
                                    </div>
                                </div>
                                <div class="smp-snip-row">
                                    <span class="smp-snip-label">BĐT & Logic</span>
                                    <div class="smp-snip-btns">
                                        <button class="smp-snip-btn" data-snip="\\le">$\\le$</button>
                                        <button class="smp-snip-btn" data-snip="\\ge">$\\ge$</button>
                                        <button class="smp-snip-btn" data-snip="\\neq">$\\neq$</button>
                                        <button class="smp-snip-btn" data-snip="\\equiv">$\\equiv$</button>
                                        <button class="smp-snip-btn" data-snip="\\pmod{m}">$\\pmod{m}$</button>
                                        <button class="smp-snip-btn" data-snip="\\forall">$\\forall$</button>
                                        <button class="smp-snip-btn" data-snip="\\exists">$\\exists$</button>
                                        <button class="smp-snip-btn" data-snip="\\mid">$\\mid$</button>
                                        <button class="smp-snip-btn" data-snip="\\nmid">$\\nmid$</button>
                                    </div>
                                </div>
                                <div class="smp-snip-row">
                                    <span class="smp-snip-label">Tập hợp</span>
                                    <div class="smp-snip-btns">
                                        <button class="smp-snip-btn" data-snip="\\mathbb{N}">$\\mathbb{N}$</button>
                                        <button class="smp-snip-btn" data-snip="\\mathbb{Z}">$\\mathbb{Z}$</button>
                                        <button class="smp-snip-btn" data-snip="\\mathbb{Q}">$\\mathbb{Q}$</button>
                                        <button class="smp-snip-btn" data-snip="\\mathbb{R}">$\\mathbb{R}$</button>
                                        <button class="smp-snip-btn" data-snip="\\mathbb{C}">$\\mathbb{C}$</button>
                                        <button class="smp-snip-btn" data-snip="\\in">$\\in$</button>
                                        <button class="smp-snip-btn" data-snip="\\notin">$\\notin$</button>
                                        <button class="smp-snip-btn" data-snip="\\subset">$\\subset$</button>
                                        <button class="smp-snip-btn" data-snip="\\cup">$\\cup$</button>
                                        <button class="smp-snip-btn" data-snip="\\cap">$\\cap$</button>
                                        <button class="smp-snip-btn" data-snip="\\emptyset">$\\emptyset$</button>
                                    </div>
                                </div>
                                <div class="smp-snip-row">
                                    <span class="smp-snip-label">Chữ Hy Lạp</span>
                                    <div class="smp-snip-btns">
                                        <button class="smp-snip-btn" data-snip="\\alpha">$\\alpha$</button>
                                        <button class="smp-snip-btn" data-snip="\\beta">$\\beta$</button>
                                        <button class="smp-snip-btn" data-snip="\\gamma">$\\gamma$</button>
                                        <button class="smp-snip-btn" data-snip="\\delta">$\\delta$</button>
                                        <button class="smp-snip-btn" data-snip="\\varphi">$\\varphi$</button>
                                        <button class="smp-snip-btn" data-snip="\\pi">$\\pi$</button>
                                        <button class="smp-snip-btn" data-snip="\\theta">$\\theta$</button>
                                        <button class="smp-snip-btn" data-snip="\\lambda">$\\lambda$</button>
                                        <button class="smp-snip-btn" data-snip="\\mu">$\\mu$</button>
                                        <button class="smp-snip-btn" data-snip="\\sigma">$\\sigma$</button>
                                        <button class="smp-snip-btn" data-snip="\\omega">$\\omega$</button>
                                        <button class="smp-snip-btn" data-snip="\\Omega">$\\Omega$</button>
                                    </div>
                                </div>
                                <div class="smp-snip-row">
                                    <span class="smp-snip-label">Môi trường</span>
                                    <div class="smp-snip-btns">
                                        <button class="smp-snip-btn" data-snip="\\begin{align*}\n  \n\\end{align*}">align</button>
                                        <button class="smp-snip-btn" data-snip="\\begin{cases}\n  & \\\\\n  &\n\\end{cases}">cases</button>
                                        <button class="smp-snip-btn" data-snip="\\begin{pmatrix}\na & b \\\\\nc & d\n\\end{pmatrix}">matrix</button>
                                    </div>
                                </div>
                                <div class="smp-snip-row">
                                    <span class="smp-snip-label">Cấu trúc</span>
                                    <div class="smp-snip-btns">
                                        <button class="smp-snip-btn" data-snip="\\left( \\right)">( )</button>
                                        <button class="smp-snip-btn" data-snip="\\left[ \\right]">[ ]</button>
                                        <button class="smp-snip-btn" data-snip="\\overline{AB}">$\\overline{AB}$</button>
                                        <button class="smp-snip-btn" data-snip="\\vec{v}">$\\vec{v}$</button>
                                        <button class="smp-snip-btn" data-snip="\\binom{n}{k}">$\\binom{n}{k}$</button>
                                        <button class="smp-snip-btn" data-snip="\\gcd(a,b)">gcd</button>
                                        <button class="smp-snip-btn" data-snip="\\lfloor x \\rfloor">$\\lfloor x \\rfloor$</button>
                                        <button class="smp-snip-btn" data-snip="\\lceil x \\rceil">$\\lceil x \\rceil$</button>
                                    </div>
                                </div>
                                <div class="smp-snip-row">
                                    <span class="smp-snip-label">Định dạng</span>
                                    <div class="smp-snip-btns">
                                        <button class="smp-snip-btn" data-snip="\\Rightarrow">$\\Rightarrow$</button>
                                        <button class="smp-snip-btn" data-snip="\\Leftarrow">$\\Leftarrow$</button>
                                        <button class="smp-snip-btn" data-snip="\\textbf{}"><b>B</b></button>
                                        <button class="smp-snip-btn" data-snip="\\textit{}"><i>I</i></button>
                                        <button class="smp-snip-btn" data-snip="\\textbf{Bài toán.} ">Bài Toán</button>
                                        <button class="smp-snip-btn" data-snip="\\textbf{Lời giải.} ">Lời Giải</button>
                                        <button class="smp-snip-btn" data-snip="\\textbf{Bổ đề.} ">Bổ Đề</button>
                                        <button class="smp-snip-btn" data-snip="\\textbf{Định lý.} ">Định Lý</button>
                                    </div>
                                </div>
                            </div>

                            <!-- Workspace 2 Cột: Input bên trái & Preview bên phải -->
                            <div class="smp-workspace">
                                <div class="smp-pane">
                                    <div class="smp-pane-header">
                                        <span class="smp-pane-title">Soạn Thảo</span>
                                        <span class="smp-pane-meta" id="smp-char-meta">0 ký tự | 0 từ | 0 dòng</span>
                                    </div>
                                    <div class="smp-editor-box">
                                        <textarea class="smp-textarea" id="smp-compose-input" spellcheck="false" placeholder="Gõ công thức tại đây (ví dụ: gõ \\fr rồi ấn Enter ra phân số)...&#10;&#10;Theo BĐT AM-GM ta có:&#10;$$ \\frac{a}{b+c} + \\frac{b}{c+a} + \\frac{c}{a+b} \\ge \\frac{3}{2} $$"></textarea>
                                        <!-- Danh sách popup gợi ý lệnh tự động -->
                                        <div class="smp-autocomplete-popup" id="smp-autocomplete-popup"></div>
                                    </div>
                                </div>
                                <div class="smp-pane">
                                    <div class="smp-pane-header">
                                        <span class="smp-pane-title">Xem Trước Trực Tiếp</span>
                                    </div>
                                    <div class="smp-preview-box" id="smp-compose-preview"></div>
                                </div>
                            </div>
                        </div>

                        <!-- 2. GIAO DIỆN BIÊN DỊCH VĂN BẢN & MÃ LATEX ĐẶT BÊN DƯỚI -->
                        <div id="smp-panel-translate" style="display: none;">
                            <div class="smp-translate-view" id="smp-translate-view"></div>
                            <div class="smp-translate-raw-box">
                                <div class="smp-pane-header">
                                    <span class="smp-pane-title">Mã \LaTeX</span>
                                </div>
                                <textarea class="smp-raw-textarea" id="smp-raw-textarea" spellcheck="false" placeholder="Mã \LaTeX sạch tự động xuất hiện tại đây (chỉnh sửa trực tiếp sẽ tự cập nhật bản xem phía trên)..."></textarea>
                            </div>
                        </div>
                    </div>

                    <div class="smp-footer">
                        <div class="smp-footer-left">
                            <div class="smp-model-pill" id="smp-model-pill" title="Chuyển đổi mô hình nhận diện LaTeX (Max: Micro-AI v5.0 | Min: Heuristic rút gọn)">
                                <button type="button" class="smp-model-btn active" id="smp-model-btn-max" data-model="max">Max</button>
                                <button type="button" class="smp-model-btn" id="smp-model-btn-min" data-model="min">Min</button>
                            </div>
                        </div>
                        <div class="smp-footer-actions">
                            <button class="smp-action-btn btn-primary" id="smp-btn-insert" title="Chèn vào bình luận (Ctrl+Enter)">
                                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><path d="m5 12 7-7 7 7"/><path d="M12 19V5"/></svg>
                            </button>
                            <button class="smp-action-btn" id="smp-btn-copy-image" title="Chép ảnh công thức nét cao vào Clipboard (Ctrl+V để dán ảnh vào Facebook)">
                                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect width="18" height="18" x="3" y="3" rx="2" ry="2"/><circle cx="9" cy="9" r="2"/><path d="m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21"/></svg>
                            </button>
                            <button class="smp-action-btn" id="smp-btn-copy-code" title="Sao chép mã \LaTeX">
                                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect width="14" height="14" x="8" y="8" rx="2" ry="2"/><path d="M4 16c-1.1 0-2-.9-2-2V4c0-1.1.9-2 2-2h10c1.1 0 2 .9 2 2"/></svg>
                            </button>
                        </div>
                    </div>
                    <div class="smp-toast" id="smp-toast">✓ Đã sao chép!</div>
                </div>
            `;
            root.appendChild(backdrop);
            bindModalEvents(backdrop);
            initThemePreference(backdrop);
            initModelPreference(backdrop);
        }
        return backdrop;
    }

    /**
     * Khởi tạo và đồng bộ chế độ Sáng / Tối (Mặc định là Sáng, gạt sang là Tối)
     */
    function initThemePreference(backdrop) {
        const dialog = backdrop.querySelector('#smp-dialog');
        const toggleInput = backdrop.querySelector('#smp-theme-toggle-input');
        
        // Mặc định ban đầu là Sáng (light)
        const savedTheme = localStorage.getItem('smp_latex_theme') || 'light';

        function applyTheme(theme) {
            if (theme === 'dark') {
                dialog.classList.remove('light-theme');
                if (toggleInput) toggleInput.checked = true;
            } else {
                dialog.classList.add('light-theme');
                if (toggleInput) toggleInput.checked = false;
            }
        }

        applyTheme(savedTheme);

        if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
            chrome.storage.local.get(['smp_latex_theme'], (res) => {
                if (res && res.smp_latex_theme) {
                    applyTheme(res.smp_latex_theme);
                    localStorage.setItem('smp_latex_theme', res.smp_latex_theme);
                }
            });
        }

        if (toggleInput) {
            toggleInput.addEventListener('change', () => {
                const isDark = toggleInput.checked;
                const newTheme = isDark ? 'dark' : 'light';
                applyTheme(newTheme);
                localStorage.setItem('smp_latex_theme', newTheme);
                if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
                    chrome.storage.local.set({ smp_latex_theme: newTheme });
                }
            });
        }
    }

    /**
     * Khởi tạo và quản lý chuyển đổi Model AI (Max / Min)
     */
    function applyModelPreference(backdrop, model) {
        currentModelPreference = model === 'min' ? 'min' : 'max';
        if (window.SMPNormalizer && typeof window.SMPNormalizer.setModel === 'function') {
            window.SMPNormalizer.setModel(currentModelPreference);
        }
        localStorage.setItem('smp_latex_model', currentModelPreference);
        if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
            chrome.storage.local.set({ smp_latex_model: currentModelPreference });
        }

        const btnMax = backdrop.querySelector('#smp-model-btn-max');
        const btnMin = backdrop.querySelector('#smp-model-btn-min');
        if (btnMax && btnMin) {
            if (currentModelPreference === 'min') {
                btnMin.classList.add('active');
                btnMax.classList.remove('active');
            } else {
                btnMax.classList.add('active');
                btnMin.classList.remove('active');
            }
        }

        // Tái biên dịch realtime văn bản hiện hành nếu đang mở
        if (currentTranslateRawText) {
            const normalized = window.SMPNormalizer ? 
                window.SMPNormalizer.normalizeMathText(currentTranslateRawText, currentModelPreference) : 
                { cleanLatex: currentTranslateRawText, mathCount: 1 };

            const translateView = backdrop.querySelector('#smp-translate-view');
            const rawTextarea = backdrop.querySelector('#smp-raw-textarea');
            if (rawTextarea) rawTextarea.value = normalized.cleanLatex;
            if (translateView) renderLatexContent(translateView, normalized.cleanLatex);
        }
    }

    function initModelPreference(backdrop) {
        const savedModel = localStorage.getItem('smp_latex_model') || 'max';
        applyModelPreference(backdrop, savedModel);

        if (typeof chrome !== 'undefined' && chrome.storage && chrome.storage.local) {
            chrome.storage.local.get(['smp_latex_model'], (res) => {
                if (res && res.smp_latex_model) {
                    applyModelPreference(backdrop, res.smp_latex_model);
                }
            });
        }

        const btnMax = backdrop.querySelector('#smp-model-btn-max');
        const btnMin = backdrop.querySelector('#smp-model-btn-min');
        if (btnMax) {
            btnMax.addEventListener('click', (e) => {
                e.stopPropagation();
                applyModelPreference(backdrop, 'max');
                showToast(backdrop, 'Đã chuyển sang mô hình Max (AI v5.0)');
            });
        }
        if (btnMin) {
            btnMin.addEventListener('click', (e) => {
                e.stopPropagation();
                applyModelPreference(backdrop, 'min');
                showToast(backdrop, 'Đã chuyển sang mô hình Min (Heuristic)');
            });
        }
    }


    /**
     * Hiển thị thông báo Toast
     */
    function showToast(backdrop, msg) {
        const toast = backdrop.querySelector('#smp-toast');
        if (!toast) return;
        toast.textContent = msg;
        toast.classList.add('show');
        clearTimeout(toast._timer);
        toast._timer = setTimeout(() => {
            toast.classList.remove('show');
        }, 2600);
    }

    /**
     * Escape các ký tự HTML nguy hiểm bên ngoài công thức toán
     */
    function escapeHtml(str) {
        if (!str) return '';
        return str
            .replace(/&/g, '&amp;')
            .replace(/</g, '&lt;')
            .replace(/>/g, '&gt;');
    }

    /**
     * Tách biệt các vùng văn bản bên ngoài chế độ toán học để xử lý an toàn
     */
    function processOutsideMath(src, fn) {
        if (!src) return '';
        const mathRegex = /(\$\$[\s\S]*?\$\$|\\\[[\s\S]*?\\\]|\\begin\{(?:cases|matrix|pmatrix|bmatrix|vmatrix|Vmatrix|aligned|gathered|array|equation|align|gather|multline)\*?\}[\s\S]*?\\end\{(?:cases|matrix|pmatrix|bmatrix|vmatrix|Vmatrix|aligned|gathered|array|equation|align|gather|multline)\*?\}|(?<!\\)\$[\s\S]*?(?<!\\)\$|\\\([\s\S]*?\\\))/g;

        let result = '';
        let lastIndex = 0;
        let match;

        while ((match = mathRegex.exec(src)) !== null) {
            const textPart = src.substring(lastIndex, match.index);
            result += fn(textPart);
            result += match[0];
            lastIndex = mathRegex.lastIndex;
        }

        const tail = src.substring(lastIndex);
        result += fn(tail);
        return result;
    }

    /**
     * Thay thế lệnh có cặp ngoặc nhọn lồng nhau an toàn (vd \textbf{...}, \textit{...})
     */
    function replaceBracedCommand(str, cmd, openTag, closeTag) {
        if (!str || !str.includes(cmd)) return str;
        let pos = 0;
        while ((pos = str.indexOf(cmd, pos)) !== -1) {
            let braceStart = pos + cmd.length;
            while (braceStart < str.length && str[braceStart] === ' ') braceStart++;
            if (braceStart >= str.length || str[braceStart] !== '{') {
                pos += cmd.length;
                continue;
            }

            const start = braceStart + 1;
            let depth = 1;
            let i = start;
            while (i < str.length && depth > 0) {
                const ch = str[i];
                const prev = i > 0 ? str[i - 1] : '';
                if (ch === '{' && prev !== '\\') depth++;
                else if (ch === '}' && prev !== '\\') depth--;
                i++;
            }

            if (depth === 0) {
                const inner = str.substring(start, i - 1);
                const processedInner = replaceBracedCommand(inner, cmd, openTag, closeTag);
                const replacement = openTag + processedInner + closeTag;
                str = str.substring(0, pos) + replacement + str.substring(i);
                pos += replacement.length;
            } else {
                pos += cmd.length;
            }
        }
        return str;
    }

    /**
     * Xử lý lệnh đổi màu \textcolor{color}{text}
     */
    function replaceTextColor(str) {
        if (!str || !str.includes('\\textcolor')) return str;
        let pos = 0;
        while ((pos = str.indexOf('\\textcolor', pos)) !== -1) {
            let brace1 = pos + 10;
            while (brace1 < str.length && str[brace1] === ' ') brace1++;
            if (brace1 >= str.length || str[brace1] !== '{') { pos += 10; continue; }
            const close1 = str.indexOf('}', brace1);
            if (close1 === -1) { pos += 10; continue; }
            const color = str.substring(brace1 + 1, close1).trim();

            let brace2 = close1 + 1;
            while (brace2 < str.length && str[brace2] === ' ') brace2++;
            if (brace2 >= str.length || str[brace2] !== '{') { pos += 10; continue; }

            const start = brace2 + 1;
            let depth = 1;
            let i = start;
            while (i < str.length && depth > 0) {
                const ch = str[i];
                const prev = i > 0 ? str[i - 1] : '';
                if (ch === '{' && prev !== '\\') depth++;
                else if (ch === '}' && prev !== '\\') depth--;
                i++;
            }

            if (depth === 0) {
                const inner = str.substring(start, i - 1);
                const replacement = `<span style="color:${color}">${inner}</span>`;
                str = str.substring(0, pos) + replacement + str.substring(i);
                pos += replacement.length;
            } else {
                pos += 10;
            }
        }
        return str;
    }

    /**
     * Xử lý hộp màu nền \colorbox{bg}{text}
     */
    function replaceColorBox(str) {
        if (!str || !str.includes('\\colorbox')) return str;
        let pos = 0;
        while ((pos = str.indexOf('\\colorbox', pos)) !== -1) {
            let brace1 = pos + 9;
            while (brace1 < str.length && str[brace1] === ' ') brace1++;
            if (brace1 >= str.length || str[brace1] !== '{') { pos += 9; continue; }
            const close1 = str.indexOf('}', brace1);
            if (close1 === -1) { pos += 9; continue; }
            const bg = str.substring(brace1 + 1, close1).trim();

            let brace2 = close1 + 1;
            while (brace2 < str.length && str[brace2] === ' ') brace2++;
            if (brace2 >= str.length || str[brace2] !== '{') { pos += 9; continue; }

            const start = brace2 + 1;
            let depth = 1;
            let i = start;
            while (i < str.length && depth > 0) {
                const ch = str[i];
                const prev = i > 0 ? str[i - 1] : '';
                if (ch === '{' && prev !== '\\') depth++;
                else if (ch === '}' && prev !== '\\') depth--;
                i++;
            }

            if (depth === 0) {
                const inner = str.substring(start, i - 1);
                const replacement = `<span style="background-color:${bg}; padding: 2px 4px; border-radius: 3px;">${inner}</span>`;
                str = str.substring(0, pos) + replacement + str.substring(i);
                pos += replacement.length;
            } else {
                pos += 9;
            }
        }
        return str;
    }

    /**
     * Xử lý \fbox, \framebox, \boxed
     */
    function parseLatexFbox(str) {
        if (!str || (!str.includes('\\fbox') && !str.includes('\\framebox') && !str.includes('\\boxed'))) return str;
        const keywords = ['\\fbox', '\\framebox', '\\boxed'];
        for (let k = 0; k < keywords.length; k++) {
            const kw = keywords[k];
            let pos = 0;
            while ((pos = str.indexOf(kw, pos)) !== -1) {
                let braceStart = pos + kw.length;
                while (braceStart < str.length && str[braceStart] === ' ') braceStart++;
                if (braceStart < str.length && str[braceStart] === '[') {
                    const optEnd = str.indexOf(']', braceStart);
                    if (optEnd !== -1) {
                        braceStart = optEnd + 1;
                        while (braceStart < str.length && str[braceStart] === ' ') braceStart++;
                    }
                }
                if (braceStart >= str.length || str[braceStart] !== '{') {
                    pos += kw.length;
                    continue;
                }

                const start = braceStart + 1;
                let depth = 1;
                let i = start;
                while (i < str.length && depth > 0) {
                    const ch = str[i];
                    const prev = i > 0 ? str[i - 1] : '';
                    if (ch === '{' && prev !== '\\') depth++;
                    else if (ch === '}' && prev !== '\\') depth--;
                    i++;
                }

                if (depth === 0) {
                    let inner = str.substring(start, i - 1);
                    inner = parseLatexFbox(inner);
                    if (/\\(frac|sqrt|sum|prod|int|alpha|beta|gamma|Delta|pi|le|ge|neq|equiv|forall|exists|in|subset)\b/.test(inner) && !inner.includes('$')) {
                        inner = '$' + inner + '$';
                    }
                    const replacement = '<span class="latex-fbox">' + inner + '</span>';
                    str = str.substring(0, pos) + replacement + str.substring(i);
                    pos += replacement.length;
                } else {
                    pos += kw.length;
                }
            }
        }
        return str;
    }

    /**
     * Tách các ô trong hàng bảng (&)
     */
    function splitTableCells(rowStr) {
        const cells = [];
        let current = '';
        let inMath = false;
        let depth = 0;

        for (let i = 0; i < rowStr.length; i++) {
            const ch = rowStr[i];
            const prev = i > 0 ? rowStr[i - 1] : '';

            if (ch === '$' && prev !== '\\') {
                inMath = !inMath;
            } else if (ch === '{' && prev !== '\\') {
                depth++;
            } else if (ch === '}' && prev !== '\\') {
                if (depth > 0) depth--;
            }

            if (ch === '&' && !inMath && depth === 0) {
                cells.push(current);
                current = '';
            } else {
                current += ch;
            }
        }
        cells.push(current);
        return cells;
    }

    /**
     * Xử lý môi trường bảng \begin{tabular}{...} ... \end{tabular}
     */
    function parseLatexTabular(str) {
        if (!str || !str.includes('\\begin{tabular')) return str;

        str = str.replace(/\\\[\s*(\\begin\{tabular\}[\s\S]*?\\end\{tabular\})\s*\\\]/gi, '$1');

        const regex = /\\begin\{tabular\}(?:\[[^\]]*\])?\{([^}]*)\}([\s\S]*?)\\end\{tabular\}/gi;

        return str.replace(regex, function(match, colSpec, tableBody) {
            const colDefs = [];
            let cleanColSpec = colSpec.replace(/\s+/g, '');
            cleanColSpec = cleanColSpec.replace(/\*\{(\d+)\}\{([^}]+)\}/g, function(_, count, spec) {
                return spec.repeat(parseInt(count, 10));
            });

            let hasLeftBorder = false;
            if (cleanColSpec.startsWith('|')) {
                hasLeftBorder = true;
                cleanColSpec = cleanColSpec.replace(/^\|+/, '');
            }

            for (let c = 0; c < cleanColSpec.length; c++) {
                const ch = cleanColSpec[c];
                if (ch === 'l' || ch === 'c' || ch === 'r' || ch === 'p') {
                    const align = ch === 'r' ? 'right' : (ch === 'c' ? 'center' : 'left');
                    let borderRight = false;
                    if (c + 1 < cleanColSpec.length && cleanColSpec[c + 1] === '|') {
                        borderRight = true;
                    }
                    colDefs.push({ align: align, borderRight: borderRight });
                }
            }

            const rawRows = tableBody.split(/\\\\(?:\[[^\]]*\])?/);
            const htmlRows = [];

            for (let r = 0; r < rawRows.length; r++) {
                let rowStr = rawRows[r].trim();
                if (!rowStr) continue;

                let hasTopBorder = false;
                let hasBottomBorder = false;

                while (rowStr.startsWith('\\hline')) {
                    hasTopBorder = true;
                    rowStr = rowStr.replace(/^\\hline\s*/, '').trim();
                }

                while (rowStr.endsWith('\\hline')) {
                    hasBottomBorder = true;
                    rowStr = rowStr.replace(/\\hline\s*$/, '').trim();
                }

                if (rowStr.includes('\\hline')) {
                    hasTopBorder = true;
                    rowStr = rowStr.replace(/\\hline/g, '').trim();
                }

                if (!rowStr) continue;

                const cells = splitTableCells(rowStr);
                let trHtml = '<tr' + (hasTopBorder ? ' class="border-top"' : '') + (hasBottomBorder ? ' class="border-bottom"' : '') + '>';
                let currentColIndex = 0;

                for (let colIdx = 0; colIdx < cells.length; colIdx++) {
                    const rawCell = cells[colIdx].trim();
                    let cellContent = rawCell;
                    let colSpan = 1;
                    let cellAlign = null;
                    let cellBorderRight = false;
                    let cellBorderLeft = false;

                    const multiMatch = cellContent.match(/^\\multicolumn\{(\d+)\}\{([^}]*)\}\{([\s\S]*)\}$/);
                    if (multiMatch) {
                        colSpan = parseInt(multiMatch[1], 10);
                        const multiAlignSpec = multiMatch[2].trim();
                        cellContent = multiMatch[3].trim();
                        if (multiAlignSpec.includes('r')) cellAlign = 'right';
                        else if (multiAlignSpec.includes('c')) cellAlign = 'center';
                        else cellAlign = 'left';

                        if (multiAlignSpec.startsWith('|')) cellBorderLeft = true;
                        if (multiAlignSpec.endsWith('|')) cellBorderRight = true;
                    }

                    const colDef = colDefs[currentColIndex] || { align: 'left', borderRight: false };
                    const finalAlign = cellAlign || colDef.align;
                    const borderClass = [];

                    if ((currentColIndex === 0 && hasLeftBorder) || cellBorderLeft) borderClass.push('border-left');
                    if (colDef.borderRight || cellBorderRight) borderClass.push('border-right');
                    if (hasTopBorder) borderClass.push('border-top');
                    if (hasBottomBorder) borderClass.push('border-bottom');

                    const spanAttr = colSpan > 1 ? ' colspan="' + colSpan + '"' : '';
                    const classAttr = borderClass.length ? ' class="' + borderClass.join(' ') + '"' : '';
                    const styleAttr = ' style="text-align: ' + finalAlign + ';"';

                    trHtml += '<td' + spanAttr + classAttr + styleAttr + '>' + cellContent + '</td>';
                    currentColIndex += colSpan;
                }

                trHtml += '</tr>';
                htmlRows.push(trHtml);
            }

            return '<div class="latex-table-wrapper"><table class="latex-table">' + htmlRows.join('') + '</table></div>';
        });
    }

    /**
     * Chuyển đổi định dạng văn bản LaTeX sang HTML hoàn chỉnh
     */
    function latexToHtml(src) {
        if (!src) return '';

        // 1. Chuyển đổi môi trường table & tabular
        let s = src
            .replace(/\\begin\{table\}(?:\[[^\]]*\])?/gi, '<div class="latex-table-container">')
            .replace(/\\end\{table\}/gi, '</div>')
            .replace(/\\caption\{([^}]*)\}/gi, '<div class="latex-table-caption">$1</div>');

        s = parseLatexTabular(s);

        // 2. Xử lý các vùng văn bản bên ngoài toán học
        s = processOutsideMath(s, function(text) {
            if (!text) return '';

            // An toàn hóa HTML
            let t = escapeHtml(text);

            // Môi trường căn lề
            t = t
                .replace(/\\begin\{center\}/gi, '<div class="latex-center">')
                .replace(/\\end\{center\}/gi, '</div>')
                .replace(/\\begin\{flushleft\}/gi, '<div class="latex-flushleft">')
                .replace(/\\end\{flushleft\}/gi, '</div>')
                .replace(/\\begin\{flushright\}/gi, '<div class="latex-flushright">')
                .replace(/\\end\{flushright\}/gi, '</div>')
                .replace(/\\centering\b/gi, '<div class="latex-center">');

            // Hộp viền fbox / boxed
            t = parseLatexFbox(t);

            // Màu sắc văn bản & nền
            t = replaceTextColor(t);
            t = replaceColorBox(t);

            // Các lệnh văn bản có ngoặc nhọn
            t = replaceBracedCommand(t, '\\textbf', '<b>', '</b>');
            t = replaceBracedCommand(t, '\\textit', '<i>', '</i>');
            t = replaceBracedCommand(t, '\\underline', '<u>', '</u>');
            t = replaceBracedCommand(t, '\\emph', '<em>', '</em>');
            t = replaceBracedCommand(t, '\\texttt', '<code>', '</code>');
            t = replaceBracedCommand(t, '\\title', '<h2 class="latex-title">', '</h2>');
            t = replaceBracedCommand(t, '\\author', '<h4 class="latex-author">', '</h4>');
            t = replaceBracedCommand(t, '\\section', '<h3 class="latex-section">', '</h3>');
            t = replaceBracedCommand(t, '\\subsection', '<h4 class="latex-subsection">', '</h4>');
            t = replaceBracedCommand(t, '\\subsubsection', '<h5 class="latex-subsubsection">', '</h5>');

            // Bullets và khoảng cách
            t = t
                .replace(/\\item\s*/g, '<span class="latex-bullet">•</span> ')
                .replace(/\\noindent\s*/g, '')
                .replace(/\\quad\b/g, '&emsp;')
                .replace(/\\qquad\b/g, '&emsp;&emsp;')
                .replace(/\\dots\b|\\ldots\b/g, '…')
                .replace(/\\\\(?![a-zA-Z])/g, '<br>')
                .replace(/\\newline\b/g, '<br>')
                .replace(/\\par\b/g, '<div class="latex-par-spacer"></div>')
                .replace(/\\(medskip|bigskip|smallskip)/g, '<br>');

            // Xuống dòng tự nhiên
            t = t.replace(/\r\n/g, '\n');
            t = t.replace(/\n\s*\n/g, '<div class="latex-par-spacer"></div>');
            t = t.replace(/\n/g, '<br>');

            return t;
        });

        return s;
    }

    /**
     * Render LaTeX và công thức toán học vào phần tử DOM
     */
    function renderLatexContent(element, latexText) {
        if (!element) return;
        const html = latexToHtml(latexText || '');
        element.innerHTML = html;
        if (typeof renderMathInElement === 'function') {
            renderMathInElement(element, {
                delimiters: [
                    { left: '$$', right: '$$', display: true },
                    { left: '$', right: '$', display: false },
                    { left: '\\(', right: '\\)', display: false },
                    { left: '\\[', right: '\\]', display: true },
                    { left: '\\begin{equation}', right: '\\end{equation}', display: true },
                    { left: '\\begin{align}', right: '\\end{align}', display: true },
                    { left: '\\begin{align*}', right: '\\end{align*}', display: true },
                    { left: '\\begin{gather}', right: '\\end{gather}', display: true },
                    { left: '\\begin{gather*}', right: '\\end{gather*}', display: true },
                    { left: '\\begin{cases}', right: '\\end{cases}', display: true },
                    { left: '\\begin{matrix}', right: '\\end{matrix}', display: true },
                    { left: '\\begin{pmatrix}', right: '\\end{pmatrix}', display: true },
                    { left: '\\begin{bmatrix}', right: '\\end{bmatrix}', display: true }
                ],
                throwOnError: false,
                errorColor: '#f87171'
            });
        }
    }

    /**
     * Render các công thức trên nút thanh công cụ
     */
    function renderToolbarMath(backdrop) {
        const toolbar = backdrop.querySelector('#smp-snippet-toolbar');
        if (toolbar && !toolbar._mathRendered) {
            toolbar._mathRendered = true;
            if (typeof renderMathInElement === 'function') {
                renderMathInElement(toolbar, {
                    delimiters: [
                        { left: '$', right: '$', display: false }
                    ],
                    throwOnError: false
                });
            }
        }
    }

    /**
     * Chuyển Tab (Soạn Thảo / Biên Dịch / Mã Công Thức)
     */
    function switchTab(root, tab) {
        currentActiveTab = tab === 'translate' ? 'translate' : 'compose';
        const btnCompose = root.querySelector('#smp-btn-tab-compose');
        const btnTranslate = root.querySelector('#smp-btn-tab-translate');

        const panelCompose = root.querySelector('#smp-panel-compose');
        const panelTranslate = root.querySelector('#smp-panel-translate');

        const composeInput = root.querySelector('#smp-compose-input');
        const composePreview = root.querySelector('#smp-compose-preview');
        const translateView = root.querySelector('#smp-translate-view');
        const rawTextarea = root.querySelector('#smp-raw-textarea');

        [btnCompose, btnTranslate].forEach(btn => btn && btn.classList.remove('active'));
        [panelCompose, panelTranslate].forEach(p => p && (p.style.display = 'none'));

        if (currentActiveTab === 'compose') {
            if (btnCompose) btnCompose.classList.add('active');
            if (panelCompose) panelCompose.style.display = 'flex';
            if (composeInput && composePreview) {
                renderLatexContent(composePreview, composeInput.value);
                composeInput.focus();
            }
            renderToolbarMath(root);
        } else {
            if (btnTranslate) btnTranslate.classList.add('active');
            if (panelTranslate) panelTranslate.style.display = 'flex';
            if (rawTextarea && translateView) {
                renderLatexContent(translateView, rawTextarea.value);
            }
        }
    }

    /**
     * Mở hộp thoại ở chế độ Biên Dịch (bôi đen đoạn văn bản)
     */
    function showTranslateModal(rawText) {
        const root = ensureModalHost();
        const backdrop = createModalDom();

        currentTranslateRawText = rawText || '';
        const normalized = window.SMPNormalizer ? 
            window.SMPNormalizer.normalizeMathText(currentTranslateRawText, currentModelPreference) : 
            { cleanLatex: currentTranslateRawText, mathCount: 1 };

        const translateView = root.querySelector('#smp-translate-view');
        const rawTextarea = root.querySelector('#smp-raw-textarea');

        if (rawTextarea) {
            rawTextarea.value = normalized.cleanLatex;
        }
        if (translateView) {
            renderLatexContent(translateView, normalized.cleanLatex);
        }

        switchTab(root, 'translate');

        requestAnimationFrame(() => {
            backdrop.classList.add('active');
        });
    }

    /**
     * Mở hộp thoại ở chế độ Soạn Thảo (chuột phải ô cmt hoặc phím tắt)
     */
    function showComposerModal() {
        const root = ensureModalHost();
        const backdrop = createModalDom();

        const composeInput = root.querySelector('#smp-compose-input');
        const composePreview = root.querySelector('#smp-compose-preview');

        // Khôi phục nháp đã lưu
        if (composeInput && !composeInput.value) {
            const savedDraft = localStorage.getItem('smp_composer_draft');
            if (savedDraft) {
                composeInput.value = savedDraft;
            }
        }

        if (composeInput && composePreview) {
            renderLatexContent(composePreview, composeInput.value);
            updateMetaCounts(backdrop, composeInput.value);
        }

        switchTab(root, 'compose');

        requestAnimationFrame(() => {
            backdrop.classList.add('active');
            if (composeInput) composeInput.focus();
            renderToolbarMath(backdrop);
        });
    }

    /**
     * Cập nhật số ký tự, từ, dòng chuẩn SMP LaTeX Editor
     */
    function updateMetaCounts(backdrop, text) {
        const charMeta = backdrop.querySelector('#smp-char-meta');
        if (!charMeta) return;
        const val = text || '';
        const words = val.trim().split(/\s+/).filter(x => x.length > 0).length;
        const lines = val.length === 0 ? 0 : val.split('\n').length;
        charMeta.textContent = `${val.length} ký tự | ${words} từ | ${lines} dòng`;
    }

    /**
     * Chèn snippet vào ô soạn thảo
     */
    function insertSnippet(textarea, snipText) {
        if (!textarea) return;
        textarea.focus();
        const start = textarea.selectionStart;
        const end = textarea.selectionEnd;
        const sel = textarea.value.substring(start, end);

        let insertVal = snipText;
        let cursorOffset = insertVal.length;

        if (snipText.includes('{a}') || snipText.includes('{x}')) {
            if (sel) {
                insertVal = snipText.replace('{a}', `{${sel}}`).replace('{x}', `{${sel}}`);
            }
        } else if (snipText === '^{n}' && sel) {
            insertVal = `^{${sel}}`;
        } else if (snipText === '_{n}' && sel) {
            insertVal = `_{${sel}}`;
        } else if (sel) {
            insertVal = snipText + sel;
        }

        const before = textarea.value.substring(0, start);
        const after = textarea.value.substring(end);
        textarea.value = before + insertVal + after;
        textarea.selectionStart = textarea.selectionEnd = start + cursorOffset;

        textarea.dispatchEvent(new Event('input', { bubbles: true }));
    }

    /**
     * Quản lý Autocomplete Hint khi gõ \
     */
    function handleAutocompleteInput(textarea, popupEl) {
        currentEditorTarget = textarea;
        const cur = textarea.selectionStart;
        const textBefore = textarea.value.slice(0, cur);
        const match = textBefore.match(/\\[a-zA-Z]*$/);

        if (!match) {
            popupEl.classList.remove('show');
            filteredHints = [];
            return;
        }

        const query = match[0];
        filteredHints = LATEX_SNIPPETS.filter(item => item.text.startsWith(query));

        if (filteredHints.length === 0) {
            popupEl.classList.remove('show');
            return;
        }

        activeHintIndex = 0;
        renderHintList(popupEl);
        popupEl.classList.add('show');
    }

    function renderHintList(popupEl) {
        popupEl.innerHTML = '';
        filteredHints.forEach((item, index) => {
            const div = document.createElement('div');
            div.className = `smp-hint-item ${index === activeHintIndex ? 'active' : ''}`;
            div.innerHTML = `
                <span>${item.displayText}</span>
                <span class="smp-hint-badge">Enter ↵</span>
            `;
            div.addEventListener('mousedown', (e) => {
                e.preventDefault();
                applyHint(item);
            });
            popupEl.appendChild(div);
        });
    }

    function applyHint(item) {
        if (!currentEditorTarget) return;
        const cur = currentEditorTarget.selectionStart;
        const textBefore = currentEditorTarget.value.slice(0, cur);
        const match = textBefore.match(/\\[a-zA-Z]*$/);
        if (!match) return;

        const start = cur - match[0].length;
        const after = currentEditorTarget.value.slice(cur);
        const before = currentEditorTarget.value.slice(0, start);

        currentEditorTarget.value = before + item.text + after;
        const newCur = start + item.text.length - (item.offset || 0);
        currentEditorTarget.selectionStart = currentEditorTarget.selectionEnd = newCur;

        const popupEl = shadowRoot.querySelector('#smp-autocomplete-popup');
        if (popupEl) popupEl.classList.remove('show');

        currentEditorTarget.dispatchEvent(new Event('input', { bubbles: true }));
        currentEditorTarget.focus();
    }

    /**
     * Xuất và sao chép ảnh công thức vào Clipboard (PNG độ nét cao 2.5x)
     */
    async function copyFormulaImage(backdrop) {
        let previewEl = null;
        if (currentActiveTab === 'compose') {
            previewEl = backdrop.querySelector('#smp-compose-preview');
        } else {
            previewEl = backdrop.querySelector('#smp-translate-view');
        }

        if (!previewEl || !previewEl.innerText.trim()) {
            showToast(backdrop, 'Chưa có công thức để chép ảnh!');
            return;
        }

        showToast(backdrop, 'Đang tạo ảnh công thức sắc nét...');

        try {
            const clone = previewEl.cloneNode(true);
            clone.style.position = 'fixed';
            clone.style.left = '-9999px';
            clone.style.top = '0';
            clone.style.width = 'auto';
            clone.style.maxWidth = '640px';
            clone.style.padding = '22px 26px';
            clone.style.background = '#ffffff';
            clone.style.color = '#0f172a';
            clone.style.borderRadius = '10px';
            clone.style.border = '1px solid #e2e8f0';
            clone.style.boxShadow = 'none';
            clone.style.fontFamily = '"Times New Roman", Times, serif';
            clone.style.fontSize = '18px';
            clone.style.lineHeight = '2.2';

            clone.querySelectorAll('.katex').forEach(k => {
                k.style.color = '#0f172a';
            });
            clone.querySelectorAll('b, strong').forEach(b => {
                b.style.color = '#0f172a';
            });
            clone.querySelectorAll('h2, h3, h4, h5').forEach(h => {
                h.style.color = '#0f172a';
                if (h.tagName === 'H3') h.style.borderLeftColor = '#009eb3';
            });
            clone.querySelectorAll('.latex-fbox').forEach(f => {
                f.style.borderColor = '#0f172a';
                f.style.color = '#0f172a';
            });
            clone.querySelectorAll('.latex-bullet').forEach(bl => {
                bl.style.color = '#009eb3';
            });

            document.body.appendChild(clone);

            if (typeof html2canvas === 'undefined') {
                document.body.removeChild(clone);
                showToast(backdrop, 'Công cụ tạo ảnh đang nạp, vui lòng thử lại sau 1 giây.');
                return;
            }

            const canvas = await html2canvas(clone, {
                backgroundColor: '#ffffff',
                scale: 2.5,
                logging: false,
                useCORS: true
            });

            document.body.removeChild(clone);

            canvas.toBlob(async (blob) => {
                if (!blob) {
                    showToast(backdrop, 'Không thể tạo file ảnh!');
                    return;
                }

                if (navigator.clipboard && window.ClipboardItem) {
                    try {
                        await navigator.clipboard.write([
                            new ClipboardItem({ 'image/png': blob })
                        ]);
                        showToast(backdrop, '✓ Đã chép ảnh vào Clipboard! Nhấp ô bình luận và bấm Ctrl + V để dán.');
                        return;
                    } catch (clipErr) {
                        console.warn('[SMP] Trình duyệt chặn ghi blob ảnh, chuyển sang tải file:', clipErr);
                    }
                }

                const a = document.createElement('a');
                a.href = URL.createObjectURL(blob);
                a.download = 'cong-thuc.png';
                a.click();
                showToast(backdrop, 'Đã tải ảnh cong-thuc.png về máy!');
            }, 'image/png');

        } catch (err) {
            console.error('[SMP] Lỗi xuất ảnh:', err);
            showToast(backdrop, 'Lỗi xuất ảnh: ' + (err.message || ''));
        }
    }

    /**
     * Chèn nội dung vào ô bình luận hoặc ô nhập liệu
     */
    function insertTextIntoCommentBox(backdrop) {
        let textToInsert = '';
        if (currentActiveTab === 'compose') {
            textToInsert = backdrop.querySelector('#smp-compose-input').value;
        } else {
            textToInsert = backdrop.querySelector('#smp-raw-textarea').value;
        }

        if (!textToInsert || !textToInsert.trim()) {
            showToast(backdrop, 'Nội dung đang trống!');
            return;
        }

        if (lastActiveEditable && document.body.contains(lastActiveEditable)) {
            lastActiveEditable.focus();
            const success = document.execCommand('insertText', false, textToInsert);
            if (!success) {
                if ('value' in lastActiveEditable) {
                    const start = lastActiveEditable.selectionStart || 0;
                    const end = lastActiveEditable.selectionEnd || 0;
                    const val = lastActiveEditable.value;
                    lastActiveEditable.value = val.slice(0, start) + textToInsert + val.slice(end);
                    lastActiveEditable.selectionStart = lastActiveEditable.selectionEnd = start + textToInsert.length;
                    lastActiveEditable.dispatchEvent(new Event('input', { bubbles: true }));
                }
            }
            showToast(backdrop, '✓ Đã chèn vào ô bình luận!');
        } else {
            navigator.clipboard.writeText(textToInsert).then(() => {
                showToast(backdrop, '✓ Đã sao chép! Hãy nhấp vào ô bình luận và bấm Ctrl + V.');
            });
        }
    }

    /**
     * Gắn các sự kiện (kéo thả, đóng, copy, gợi ý, phím tắt)
     */
    function bindModalEvents(backdrop) {
        const dialog = backdrop.querySelector('#smp-dialog');
        const dragHeader = backdrop.querySelector('#smp-drag-header');
        const btnClose = backdrop.querySelector('#smp-btn-close');

        const btnTabCompose = backdrop.querySelector('#smp-btn-tab-compose');
        const btnTabTranslate = backdrop.querySelector('#smp-btn-tab-translate');

        const composeInput = backdrop.querySelector('#smp-compose-input');
        const composePreview = backdrop.querySelector('#smp-compose-preview');
        const rawTextarea = backdrop.querySelector('#smp-raw-textarea');
        const autocompletePopup = backdrop.querySelector('#smp-autocomplete-popup');

        const btnInsert = backdrop.querySelector('#smp-btn-insert');
        const btnCopyImage = backdrop.querySelector('#smp-btn-copy-image');
        const btnCopyCode = backdrop.querySelector('#smp-btn-copy-code');
        const toolbar = backdrop.querySelector('#smp-snippet-toolbar');

        function closeModal() {
            backdrop.classList.remove('active');
            if (autocompletePopup) autocompletePopup.classList.remove('show');
        }

        btnClose.addEventListener('click', closeModal);
        backdrop.addEventListener('click', (e) => {
            if (e.target === backdrop) closeModal();
        });

        // Chuyển tab (Chỉ gồm Soạn Thảo và Biên Dịch)
        if (btnTabCompose) btnTabCompose.addEventListener('click', () => switchTab(backdrop, 'compose'));
        if (btnTabTranslate) btnTabTranslate.addEventListener('click', () => switchTab(backdrop, 'translate'));

        // Sự kiện gõ trực tiếp trong ô Soạn Thảo (Live Render realtime & Autocomplete)
        if (composeInput) {
            let composeDebounce = null;
            composeInput.addEventListener('input', () => {
                const val = composeInput.value;
                updateMetaCounts(backdrop, val);

                // Lưu nháp tự động
                localStorage.setItem('smp_composer_draft', val);

                // Kích hoạt gợi ý lệnh nếu vừa gõ \
                handleAutocompleteInput(composeInput, autocompletePopup);

                clearTimeout(composeDebounce);
                composeDebounce = setTimeout(() => {
                    renderLatexContent(composePreview, val);
                }, 35);
            });

            // Xử lý phím mũi tên & Enter cho Autocomplete & Tự đóng ngoặc
            composeInput.addEventListener('keydown', (e) => {
                if (autocompletePopup && autocompletePopup.classList.contains('show') && filteredHints.length > 0) {
                    if (e.key === 'ArrowDown') {
                        e.preventDefault();
                        activeHintIndex = (activeHintIndex + 1) % filteredHints.length;
                        renderHintList(autocompletePopup);
                        return;
                    } else if (e.key === 'ArrowUp') {
                        e.preventDefault();
                        activeHintIndex = (activeHintIndex - 1 + filteredHints.length) % filteredHints.length;
                        renderHintList(autocompletePopup);
                        return;
                    } else if (e.key === 'Enter' || e.key === 'Tab') {
                        e.preventDefault();
                        applyHint(filteredHints[activeHintIndex]);
                        return;
                    } else if (e.key === 'Escape') {
                        e.preventDefault();
                        autocompletePopup.classList.remove('show');
                        return;
                    }
                }

                // Tự động đóng cặp dấu ngoặc chuẩn LaTeX (Chuẩn SMP LaTeX Editor)
                const start = composeInput.selectionStart;
                const end = composeInput.selectionEnd;
                const val = composeInput.value;

                if (e.key === '$') {
                    if (start !== end) {
                        e.preventDefault();
                        const sel = val.substring(start, end);
                        composeInput.setRangeText(`$${sel}$`, start, end, 'select');
                        composeInput.dispatchEvent(new Event('input', { bubbles: true }));
                        return;
                    }
                    if (val[start] === '$') {
                        e.preventDefault();
                        composeInput.selectionStart = composeInput.selectionEnd = start + 1;
                        return;
                    }
                    e.preventDefault();
                    composeInput.setRangeText('$$', start, start, 'end');
                    composeInput.selectionStart = composeInput.selectionEnd = start + 1;
                    composeInput.dispatchEvent(new Event('input', { bubbles: true }));
                    return;
                } else if (e.key === '[' || e.key === '(' || e.key === '{') {
                    const isEscaped = start > 0 && val[start - 1] === '\\';
                    if (isEscaped) {
                        // Gõ \[ -> tự động đóng \], gõ \( -> \), gõ \{ -> \}
                        e.preventDefault();
                        const closePair = e.key === '[' ? '\\]' : (e.key === '(' ? '\\)' : '\\}');
                        if (start !== end) {
                            const sel = val.substring(start, end);
                            composeInput.setRangeText(`${e.key}${sel}${closePair}`, start, end, 'select');
                        } else {
                            composeInput.setRangeText(`${e.key}${closePair}`, start, start, 'end');
                            composeInput.selectionStart = composeInput.selectionEnd = start + 1;
                        }
                        composeInput.dispatchEvent(new Event('input', { bubbles: true }));
                        return;
                    }

                    // Ký tự ngoặc thông thường
                    const closePair = e.key === '[' ? ']' : (e.key === '(' ? ')' : '}');
                    if (start !== end) {
                        e.preventDefault();
                        const sel = val.substring(start, end);
                        composeInput.setRangeText(`${e.key}${sel}${closePair}`, start, end, 'select');
                        composeInput.dispatchEvent(new Event('input', { bubbles: true }));
                        return;
                    }

                    e.preventDefault();
                    composeInput.setRangeText(`${e.key}${closePair}`, start, start, 'end');
                    composeInput.selectionStart = composeInput.selectionEnd = start + 1;
                    composeInput.dispatchEvent(new Event('input', { bubbles: true }));
                    return;
                } else if (e.key === ']' || e.key === ')' || e.key === '}') {
                    // Nếu ký tự ngay sau con trỏ đã là dấu đóng tương ứng, nhảy qua
                    if (start === end && val[start] === e.key) {
                        e.preventDefault();
                        composeInput.selectionStart = composeInput.selectionEnd = start + 1;
                        return;
                    }
                }
            });
        }

        // Sự kiện trên ô Mã LaTeX đặt bên dưới Biên Dịch
        if (rawTextarea) {
            let rawDebounce = null;
            rawTextarea.addEventListener('input', () => {
                handleAutocompleteInput(rawTextarea, autocompletePopup);
                clearTimeout(rawDebounce);
                rawDebounce = setTimeout(() => {
                    const translateView = backdrop.querySelector('#smp-translate-view');
                    if (translateView) {
                        renderLatexContent(translateView, rawTextarea.value);
                    }
                }, 40);
            });

            rawTextarea.addEventListener('keydown', (e) => {
                const start = rawTextarea.selectionStart;
                const end = rawTextarea.selectionEnd;
                const val = rawTextarea.value;

                if (e.key === '$') {
                    if (start !== end) {
                        e.preventDefault();
                        const sel = val.substring(start, end);
                        rawTextarea.setRangeText(`$${sel}$`, start, end, 'select');
                        rawTextarea.dispatchEvent(new Event('input', { bubbles: true }));
                        return;
                    }
                    if (val[start] === '$') {
                        e.preventDefault();
                        rawTextarea.selectionStart = rawTextarea.selectionEnd = start + 1;
                        return;
                    }
                    e.preventDefault();
                    rawTextarea.setRangeText('$$', start, start, 'end');
                    rawTextarea.selectionStart = rawTextarea.selectionEnd = start + 1;
                    rawTextarea.dispatchEvent(new Event('input', { bubbles: true }));
                    return;
                } else if (e.key === '[' || e.key === '(' || e.key === '{') {
                    const isEscaped = start > 0 && val[start - 1] === '\\';
                    if (isEscaped) {
                        e.preventDefault();
                        const closePair = e.key === '[' ? '\\]' : (e.key === '(' ? '\\)' : '\\}');
                        if (start !== end) {
                            const sel = val.substring(start, end);
                            rawTextarea.setRangeText(`${e.key}${sel}${closePair}`, start, end, 'select');
                        } else {
                            rawTextarea.setRangeText(`${e.key}${closePair}`, start, start, 'end');
                            rawTextarea.selectionStart = rawTextarea.selectionEnd = start + 1;
                        }
                        rawTextarea.dispatchEvent(new Event('input', { bubbles: true }));
                        return;
                    }

                    const closePair = e.key === '[' ? ']' : (e.key === '(' ? ')' : '}');
                    if (start !== end) {
                        e.preventDefault();
                        const sel = val.substring(start, end);
                        rawTextarea.setRangeText(`${e.key}${sel}${closePair}`, start, end, 'select');
                        rawTextarea.dispatchEvent(new Event('input', { bubbles: true }));
                        return;
                    }

                    e.preventDefault();
                    rawTextarea.setRangeText(`${e.key}${closePair}`, start, start, 'end');
                    rawTextarea.selectionStart = rawTextarea.selectionEnd = start + 1;
                    rawTextarea.dispatchEvent(new Event('input', { bubbles: true }));
                    return;
                } else if (e.key === ']' || e.key === ')' || e.key === '}') {
                    if (start === end && val[start] === e.key) {
                        e.preventDefault();
                        rawTextarea.selectionStart = rawTextarea.selectionEnd = start + 1;
                        return;
                    }
                }
            });
        }

        // Click nút công thức trên thanh công cụ
        if (toolbar) {
            toolbar.addEventListener('click', (e) => {
                const btn = e.target.closest('.smp-snip-btn');
                if (btn && btn.dataset.snip) {
                    insertSnippet(composeInput, btn.dataset.snip);
                }
            });
        }

        // Nút Chèn Vào Bình Luận
        btnInsert.addEventListener('click', () => {
            insertTextIntoCommentBox(backdrop);
        });

        // Nút Chép Ảnh
        btnCopyImage.addEventListener('click', () => {
            copyFormulaImage(backdrop);
        });

        // Nút Sao Chép Mã
        btnCopyCode.addEventListener('click', () => {
            let textToCopy = '';
            if (currentActiveTab === 'compose') {
                textToCopy = composeInput.value;
            } else {
                textToCopy = rawTextarea.value;
            }

            navigator.clipboard.writeText(textToCopy).then(() => {
                btnCopyCode.classList.add('copied');
                showToast(backdrop, '✓ Đã sao chép mã \\LaTeX!');
                setTimeout(() => {
                    btnCopyCode.classList.remove('copied');
                }, 2000);
            }).catch(err => {
                console.error('[SMP] Không thể sao chép:', err);
            });
        });

        // Kéo thả di chuyển hộp thoại
        dragHeader.addEventListener('mousedown', (e) => {
            if (e.target.closest('.smp-header-actions')) return;
            isDragging = true;
            dragStartX = e.clientX;
            dragStartY = e.clientY;
            const rect = dialog.getBoundingClientRect();
            modalInitialLeft = rect.left;
            modalInitialTop = rect.top;

            dialog.style.left = `${modalInitialLeft}px`;
            dialog.style.top = `${modalInitialTop}px`;
            dialog.style.position = 'fixed';
            dialog.style.margin = '0';
        });

        window.addEventListener('mousemove', (e) => {
            if (!isDragging) return;
            const dx = e.clientX - dragStartX;
            const dy = e.clientY - dragStartY;
            dialog.style.left = `${modalInitialLeft + dx}px`;
            dialog.style.top = `${modalInitialTop + dy}px`;
        });

        window.addEventListener('mouseup', () => {
            isDragging = false;
        });

        // Phím tắt Esc
        window.addEventListener('keydown', (e) => {
            if (e.key === 'Escape' && backdrop.classList.contains('active')) {
                closeModal();
            }
        });
    }

    /**
     * Nhận tin nhắn từ background script
     */
    chrome.runtime.onMessage.addListener((request, sender, sendResponse) => {
        if (request.action === 'SMP_TRANSLATE_SELECTION') {
            let text = '';
            try {
                const domSelection = window.getSelection() ? window.getSelection().toString() : '';
                if (domSelection && domSelection.trim()) {
                    text = domSelection;
                }
            } catch (e) {}
            if (!text) {
                text = request.text || '';
            }
            showTranslateModal(text);
            sendResponse({ success: true });
        } else if (request.action === 'SMP_OPEN_COMPOSER') {
            showComposerModal();
            sendResponse({ success: true });
        } else if (request.action === 'SMP_TRANSLATE_HOTKEY') {
            const selectedText = window.getSelection().toString();
            if (selectedText && selectedText.trim()) {
                showTranslateModal(selectedText);
            } else {
                showComposerModal();
            }
            sendResponse({ success: true });
        }
    });

    console.log('[SMP] Trình Soạn Thảo & Biên Dịch đã sẵn sàng.');
})();
